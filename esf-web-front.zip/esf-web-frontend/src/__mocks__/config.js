export default {
  apiHost: 'https://example.com',
  fakeFetchDelay: 0,
}
