import en from './en';
import ru from './ru';
import kk from './kk';

export default {
  en,
  ru,
  kk,
}
