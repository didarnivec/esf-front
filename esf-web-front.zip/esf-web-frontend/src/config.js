export default {
  apiHost: 'http://localhost:3001/v1',
  fakeFetchDelay: 1000,
}
